#include "dataStructures.h"


/*std::ostream& operator<<(std::ostream& os,){
	data myData = sp->dataPointer;
	os << myData;
	return os;
}*/
